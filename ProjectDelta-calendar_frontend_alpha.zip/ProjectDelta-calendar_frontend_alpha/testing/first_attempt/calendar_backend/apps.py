from django.apps import AppConfig


class CalendarBackendConfig(AppConfig):
    name = 'calendar_backend'
